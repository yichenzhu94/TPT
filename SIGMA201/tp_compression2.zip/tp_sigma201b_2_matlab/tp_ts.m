%% TP compression d'image
close all;
clear all;
clc;

%% Charger une image 
x= double(imread('lena.pgm'));
bpp = 8; % bits per pixel
dyn = 2^bpp;


%% Calcul TO symmetrique
nDecLev = 5;
imSizeLog = log2(size(x,1));

% Calcul et affichage
[qmf, dqmf] = MakeBSFilter('Villasenor', 1); 
X_TS = FWT2_SBS(x,imSizeLog-nDecLev,qmf,dqmf);
wt_view(X_TS,nDecLev);
title(sprintf('Decomposition CQF sur %d niveaux, remise � l''�chelle des sous-bandes',nDecLev));

figure; 
imagesc(log10(abs(X_TS)+1)); 
axis image; 
axis off; 
colorbar;
title(sprintf('Decomposition CQF sur %d niveaux, �chelle log unique',nDecLev));

%% Comparaison avec les autres transform�es

% TO Orthogonale
qmf = MakeONFilter('Daubechies',8);
X_TO = FWT2_PO(x,imSizeLog-nDecLev,qmf);

% TCD
blockSize = 16;
T_DCT = blkproc(???);

DELTA= ???;
R_TO = zeros(size(DELTA));    
R_DCT = R_TO;       
R_TS = R_TO;
D_TO = zeros(size(DELTA));    
D_DCT = D_TO;       
D_TS = D_TO; 
PSNR_TO = zeros(size(DELTA)); 
PSNR_DCT = PSNR_TO; 
PSNR_TS = PSNR_TO;

for iDelta = 1:numel(DELTA),
    delta = DELTA(iDelta);
    
    % TO Orthogonale
    TOQ = qu_dz(???,???);
    h = hist(???,???,???);    
    pmf = ???;
    R_TO(iDelta) = pmfEntr(???); 
    D_TO(iDelta)=  ???;
    PSNR_TO(iDelta) = ???;    
   
    % TO Symetrique
    TSQ = qu_dz(???,???) ;
    h = hist(TSQ(:), min(TSQ(:)):max(TSQ(:)));    
    pmf = ???;
    R_TS(iDelta) = pmfEntr(???); 
    D_TS(iDelta)=  mean( (X_TS(:)-TSQ(:)).^2  );
    PSNR_TS(iDelta) = 10*log10(dyn^2/ D_TS(iDelta) );
    
    % TCD
    TCDQ = qu_dz(T_DCT,delta) ;
    h = hist(TCDQ(:), min(TCDQ(:)):max(TCDQ(:)));    
    pmf = h/sum(h);
    R_DCT(iDelta) = pmfEntr(pmf); 
    D_DCT(iDelta)=  ???;
    PSNR_DCT(iDelta) = ???;
end

%%
figure; plot(R_DCT,PSNR_DCT, R_TO,PSNR_TO,  R_TS,PSNR_TS, 'linewidth', 2)
xlabel('Rate - bpp'); ylabel('PSNR - dB');  
legend('TDC','TO', 'TO Sym','Location', 'SouthEast'); 


%%  PSNRs
r = ???
p1 = interp1(???,PSNR_TO,???);
p2 = ???
figure; plot(r,p2-p1, 'linewidth', 2)
xlabel('Rate - bpp'); ylabel('\Delta PSNR - dB');  legend('PSNR_{TS}-PSNR_{TO}'); 
line ([0 4],[0 0]);
axis([0 max(r)*1.05 min(p2-p1)-0.02 max(p2-p1)+0.02])